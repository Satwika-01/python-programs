/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void binary_search(int arr[],int n,int ele){
    int mid;
    int l,r;
    l=0,r=n-1;
    
    while(l<=r){
        mid=(l+r)/2;
        if(arr[mid]==ele){
        cout<<"Element "<<arr[mid]<<" found at position "<<mid+1;
            return;
        }
        else if(ele>arr[mid])
        l=mid+1;
        else
        r=mid-1;
    }
    cout<<"element not found in array\n";
}

int main()
{
    int arr[10],ele,i,n;
   cout<<"enter the size\n";
   cin>>n;
   cout<<"enter the elements\n";
   for(i=0;i<n;i++){
       cin>>arr[i];
   }
   cout<<"enter the element\n";
   cin>>ele;
   binary_search(arr,n,ele);
    return 0;
}
d= {
    'India':'Delhi','USA':'Washington DC',
    'Japan':'Tokyo'
    }
d.setdefault('China','Not Found')
print(d.get('India'))
#print(d.get('china','Not Found'))
print(d.get('China'))
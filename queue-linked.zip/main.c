/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void insert();
void delete();
void display();
struct node{
    int data;
    struct node*next;
};
struct node* front=NULL;
struct node*rear=NULL;

int main()
{int choice;
   while(1){
       printf(" 1 insert 2 delete 3 display 4 exit\n");
       scanf("%d",&choice);
       switch(choice){
           case 1:insert();break;
           case 2:delete();break;
           case 3:display();break;
           case 4:exit(0);break;
       }
   }
   
    return 0;
}

void insert(){
      struct node*newnode;
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("enter the value\n");
    scanf("%d",&newnode->data);
    if(rear==NULL){
        rear=newnode;
        front=newnode;
    }
    else{
        rear->next= newnode;
        rear=newnode;
    }
}

void delete(){
    if(front==NULL){
        printf("queue is empty\n");
    }
    else if(front==rear){
        front=NULL;
        rear=NULL;
    }
    else{
        front=front->next;
    }
}
void display(){
    struct node*temp;
    temp=front;
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
}

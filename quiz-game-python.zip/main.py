'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#------------------
def new_game():
    guesses = []
    correct_guesses = 0
    question_num = 1
    for key in questions:
        print("----------")
        print(key)
        for i in options[question_num-1]:
            print(i)
        guess = input("Enter your guess: A,B,C or D:")
        guess = guess.upper()
        guesses.append(guess)
        correct_guesses += check_answer(questions.get(key),guess)
        question_num+=1
        
    display(correct_guesses,guesses)       

print("-------------------")

def check_answer(answer,guess):
    if answer==guess:
        print("Correct!")
        return 1
    else:
        print("Wrong!")
        return 0
    
print("-------------------")

def display(correct_guesses,guesses):
    print("Results:")
    print("----------")
    print("Answers:", end="")
    for i in questions:
        print(questions.get(i),end=" ")
    print()    
    for i in guesses:
        print(i,end=" ")
        
    print()
    score = int((correct_guesses/len(questions))*100)
    print("your score is " ,+str(score) ,"%")
    

print("-------------------")

def play_again():
    response = input("Do you want to play again(Yes/No)")
    response = response.upper()
    if response == "YES":
        return True
    else:
        return False

print("-------------------")

#------------------------------

questions = {
    "1. What is the national fruit of India?":"A",
    "2. In which continent India is present?":"A",
    "3. How many continents are there?":"C",
    "4. Do cats belongs to Tigers Colony?":"B"
}

options = [ ["A.Mango B.Banana C.Apple D.Strawberry"],

            [ "A.Asia B.Africa C.Europe D.America"],
            
            [ "A.5 B.3 C.7 D.6"],
            
            [ "A.No B.Yes C.Sometimes D.None"]
    
    ]
new_game 
while play_again:
    new_game
print("Byeee")
'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def isprime(num):
    if num>1:
        for i in range(2,int(num/2)+1):
            if(num%i==0):
                print(num,"is not prime")
                break
            else:
                print(num,"is prime number")
    else:
        print(num,"not a prime number")
num = int(input("enter the number:"))
isprime(num)
'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
mon=int(input("month"))
if(mon ==1):
    print("31")
if(mon==2):
    print("28")
if(mon==3):
    print("31")
if(mon==4):
    print("30")
if(mon==5):
    print("31")
if(mon==6):
    print("30")
if(mon==7):
    print("31")
    
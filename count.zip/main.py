lis = [1,2,9,4,6,2,8,1]
new=[]
for i in lis:
    n=lis.count(i)
    if n>1:
        new.append(i)
print(new)
        

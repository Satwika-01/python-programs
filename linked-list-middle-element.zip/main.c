/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void print();
void middle();
struct node{
    int data;
    struct node*next;
};

int main()
{
   int n;
    struct node*newnode;
    struct node*head=NULL;
    struct node*temp;
     
   printf("enter the size of the list\n");
   scanf("%d",&n);
   while(n--){
      
       newnode=(struct node*)malloc(sizeof(struct node));
       newnode->next=NULL;
       printf("enter the data\n");
       scanf("%d",&newnode->data);
    
       
       if(head==NULL){
           head=newnode;
       }
       else{
           temp=head;
           while(temp->next!=NULL){
               temp=temp->next;
           }
           temp->next=newnode;
       }
       
   }
   printf("original linked list is\n");
       print(head);
       printf("middle element is\n");
       middle(head,head,head);

    return 0;
}

void print(struct node*head){
    struct node*temp;
    temp=head;
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    
   
}

void middle(struct node*head,struct node*slow,struct node*fast){
        
        while(fast!=NULL){
            slow=slow->next;
            fast=fast->next->next;
            
        }
        printf("the middle element is %d",slow->data);
    }
'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def feb(n):
    if(n<=0):
        print("incorrect input")
    elif(n==1):
        return 0
    elif(n==2):
        return 1
    else:
        return feb(n-1)+feb(n-2)
num = int(input("number:"))
print(feb(num))
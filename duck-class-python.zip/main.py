'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Duck:
    def walk(self):
        print("This duck is walking")
    
    def talk(self):
        print("This duck is quacking")
        
class Chicken:
    def walk(self):
        print("This chicken is walking")
        
    def talk(self):
        print("This chicken is chuckling")

class Person():
    
    def catch(self,duck):
        duck.walk()
        duck.talk()

duck = Duck()
chicken = Chicken()
person = Person()
person.catch(duck)
person.catch(chicken)

        
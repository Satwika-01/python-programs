/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int arr1[10],arr2[10],n,i,j;
  printf(" enter the number of elemets\n");
  scanf("%d",&n);
  printf(" enter the elements\n");
  for(i=0;i<n;i++){
      scanf("%d",&arr1[i]);
  }
  for(i=n-1,j=0;i>=0,j<n;i--,j++){
      arr2[j]=arr1[i];
  }
  printf(" reversal array is\n");
  for(j=0;j<n;j++){
      printf("%d ",arr2[j]);
  }
  
    return 0;
}

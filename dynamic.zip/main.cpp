/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void lar(int *arr,int n){
    for(int i=1;i<n;i++){
        if(*arr<*(arr+i))
        *arr=*(arr+i);
        
    }
    cout<< *arr;
}


int main()
{
   int n,*arr;
   n=5;
   arr=new int[n];
   if(arr==NULL)
   cout<<"MEMORY FULL\n";
   *(arr+0)=21;
   *(arr+1)=16;
   *(arr+2)=98;
   *(arr+3)=76;
   *(arr+4)=32;
   lar(arr,n);
   


    return 0;
}
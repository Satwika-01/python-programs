/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int arr[10],i,n,factor=0,fac=0;
   printf(" enter the number of elements\n");
   scanf("%d",&n);
   printf(" enter the elements\n");
   for(i=0;i<n;i++){
       scanf("%d",&arr[i]);
   }
   for(i=0;i<n;i++){
       if(arr[i]%2==0)
       factor++;
       else
       fac++;
   }
   printf(" even are %d",factor);
   printf("odd are %d",fac);

    return 0;
}

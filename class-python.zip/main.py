'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Animal:
    def eat(self):
        print("This animal is eating")
        
    def sleep(self):
        print("This animal is sleeping")
        
    def play(self):
        print("This animal is playing")
        
class Tiger(Animal):
    def roar(self):
        print("Tiger is Roaring")

class Lion(Animal):
    def playing(self):
         print("Lion is playing")
        
        
class Fish(Animal):
    def swim(elf):
        print("Fish is swimming")
        
        
tiger = Tiger()
lion = Lion()
fish = Fish()

tiger.roar()
lion.playing()
fish.swim()
fish.eat()

    
    
    
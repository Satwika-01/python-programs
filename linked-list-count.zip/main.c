/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void print();
void count();
struct node{
    int data;
    struct node*next;
};

int main()
{
   int n,ele;
  
   
   printf("enter the size of list\n");
   scanf("%d",&n);
   struct node*newnode;
   struct node*head=NULL;
   struct node*temp;
   while(n--){
       newnode=(struct node*)malloc(sizeof(struct node));
       newnode->next=NULL;
       printf("enter the data\n");
       scanf("%d",&newnode->data);
       if(head==NULL){
           head=newnode;
       }
       else{
           temp=head;
           while(temp->next!=NULL){
               temp=temp->next;
           }
           temp->next=newnode;
           
       }
   }
   printf("the list is\n");
   print(head);
   printf("enter the element of which occurence is needed\n");
   scanf("%d",&ele);
   count(head,ele);
    return 0;
}

void print(struct node*head){
    struct node*temp;
    temp=head;
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
}
void count(struct node*head,int data){
    
    struct node*temp=head;
    int count=0;
    while(temp!=NULL){
        if(temp->data==data){
            count++;
        }
        temp=temp->next;
    }
    printf("occurence of %d is %d\n",data,count);
}
'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def p(n,x):
    if x==0:
        return 1
    else:
        return n * p(n,x-1)
n=int(input("NUMBER:"))
x=int(input("POWER:"))
ans=p(n,x)
print(ans)
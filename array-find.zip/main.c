/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int search(int[],int,int);
int main()
{
   int a[10],i,key,index,n;
   printf(" enter the number f elemets\n");
   scanf(" %d",&n);
   printf(" enter the eleents\n");
   for(i=0;i<n;i++){
       scanf("%d",&a[i]);
   }
   printf(" enter the element you want to perform on\n");
   scanf("%d",&key);
   index=search(a,n,key);
   if(index==-1)
   printf(" element not found\n");
   else
   printf(" element is found at %d",index);
   return 0;
}

int search(int a[],int n,int key){
    int i;
    for(i=0;i<n;i++){
        if(a[i]==key)
        return i;
        return -1;
    }
}

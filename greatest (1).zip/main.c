/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,c;
   printf("enetr three numbers\n");
   scanf("%d%d%d",&a,&b,&c);
   if((a>b)&&(a>c))
   printf("%d is greatest\n",a);
   else if((c>a)&&(c>b))
   printf("%d is greatest\n",c);
   else
   printf("%d is greatest\n",b);
    return 0;
}

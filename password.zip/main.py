'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
spe="!@$%^&*"
cap="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
smal="abcdefghijklmnopqrstuvwxyz"
num="1234567890"
c1,c2,c3,c4=0,0,0,0
password=input("enter the password:")
length=len(password)
if length<8:
    print("invalid password")
    
else:
    for i in password:
        if i in spe:
            c1+=1 
        if i in cap:
            c2+=1
        if i in smal:
            c3+=1 
        if i in num:
            c4+=1 

    if(c1>=1 and c2>=1 and c3>=1 and c4>=1):
        print("valid")
    else:
        print("error")

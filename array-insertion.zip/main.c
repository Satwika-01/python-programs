/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int arr[10],i,n,ind,ele;
   printf(" enter the size of array\n");
   scanf("%d",&n);
   printf(" enter the elements\n");
   for(i=0;i<n;i++){
       scanf("%d",&arr[i]);
       
   }
   printf("enter thr index position\n");
   scanf("%d",&ind);
   printf(" enter th element\n");
   scanf("%d",&ele);
   for(i=n-1;i>=ind;i--){
       arr[i+1]=arr[i];
       arr[ind-1]=ele;
   }
   printf(" new array is \n");
   for(i=0;i<=n;i++){
       printf("%d ",arr[i]);
   }

    return 0;
}

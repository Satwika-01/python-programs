/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void sort(int arr[],int n){
    int i,j;
    bool swp=false;
    
    for(i=0;i<n-1;i++){
        for(j=0;j<n-i-1;j++){
           if(arr[j]>arr[j+1]){
               swap(arr[j],arr[j+1]);
               swp=true;
           }
        }
        if(swp==false)
        break;
    }
    for(i=0;i<n;i++)
    cout<<arr[i]<<" "<<endl;
    cout<<"First element is:"<<arr[0]<<endl;
    cout<<"Second element is:"<<arr[1]<<endl;
    cout<<"Third element is:"<<arr[2]<<endl;
    
}

int main()
{
   int arr[]={23,67,11,43,10,87,56};
   int size=sizeof(arr)/sizeof(arr[0]);
   sort(arr,size);

    return 0;
}
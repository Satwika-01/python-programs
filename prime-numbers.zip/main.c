/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,count=0,factor=0,n;
   printf("enter the number");
   scanf("%d",&n);
   for(i=1,count=0;count<=n;i++){
     
       for(j=1;j<=i;j++){
           if(i%j==0){
               factor++;
           }
       }
       if(factor==2){
           printf("%d  ",i);
           count++;
       }
      
       
       
      
       }
   
   

    return 0;
}

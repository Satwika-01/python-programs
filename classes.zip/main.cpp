/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
class veg{
    public:
    int price;
    string name;
    void printo1(string s1,int p1){
        cout<<"VEG is "<<s1<<endl;
        cout<<"Price is "<<p1<<endl;
    }
    void printo2(string s2,int p2){
        cout<<"VEG is "<<s2<<endl;
        cout<<"Price is "<<p2<<endl;;
    }
    
    
};

int main()
{
   veg o1;
   veg o2;
   string v1,v2;
   int p1,p2;
   cout<<"VEG:";
   cin>>v1;
   cout<<"PRICE:";
   cin>>p1;
   cout<<"VEG:";
   cin>>v2;
   cout<<"PRICE:";
   cin>>p2;
   o1.printo1(v1,p1);
   o2.printo2(v2,p2);
   

    return 0;
}
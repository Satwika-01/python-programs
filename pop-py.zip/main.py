
s=([1,2,3,4,5,6])
while(s):
    s1=s.pop()
    print(s)


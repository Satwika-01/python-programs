'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
from random import *
x=randint(1,100)
def binary(x):
    l=1
    h=x
    t=10
    while(l<=h and t):
        print("YOU ARE LEFT WITH "+str(t)+" GUSSES")
        mid=int(input("Enter the Number\n"))
        if x==mid:
            print("You won the Game")
            break
        elif mid<x:
            print("Slightly Increase your Number")
            l=mid+1
        else:
            print("Slightly Decrease your Number")
            h=mid-1
        t-=1
binary(x)
            
    
    
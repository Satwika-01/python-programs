'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def ispalindrome(word):
    mid=((len(word)-1)/2)
    start=0
    end=len(word)-1
    flag=0
    while(start<=mid):
        if(word[start]==word[end]):
            start+=1
            end-=1
        else:
            flag=1
            break
    if flag == 0:
        print("palindrome")
    else:
        print("not a palindrome")
word= input("enter the word:")
ispalindrome(word)
        
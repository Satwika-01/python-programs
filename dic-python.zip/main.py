def dictonary():
    kv={}
    kv[1]=46
    kv[3]=21
    kv[6]=76
    kv[2]=10
    kv[4]=65
    kv[5]=15
    kv={ 1:21,3:56,2:98}
        
    
    print("sorted dictionary:")
    d1=sorted(kv.items())
    print(d1)
    print("sorted dic")    
    for i in sorted(kv.keys()):
        print(i,"",end="")
dictonary()
    
    
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void value(int a,int b){
    int t;
    t=a;
    a=b;
    b=t;
}
void reference(int *a,int*b){
    int t;
    t=*a;
    *a=*b;
    *b=t;
}

int main()
{
    int a,b;
    cout<<"enter the numbers\n";
    cin>>a>>b;
    value(a,b);
    cout<<"call by value "<<a<<" "<<b<<endl;
    reference(&a,&b);
    cout<<"call by reference "<<a<<" "<<b;
    

    return 0;
}
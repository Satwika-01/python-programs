'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

mini,maxi=0,0
for i in power:
    if mini==0 and maxi==0:
        mini,maxi=power[0],power[0]
        print(mini,maxi)
    else:
        mini=min(mini,i)
        maxi=max(maxi,i)
        print(mini,maxi)
        
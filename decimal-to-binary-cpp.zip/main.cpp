/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int n=6;
    int arr[10],rem=0;
    int i=0;
    while(n!=0){
        rem=n%2;
        arr[i]=rem;
        i+=1;
        n=n/2;
        
    }
    for(int j=i-1;j>=0;j--)
    cout<<arr[j];

    return 0;
}
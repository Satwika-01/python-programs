s="online compiler"
s1=enumerate(s,0)
print(list(s1))
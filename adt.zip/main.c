/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void insert(int a[],int key,int index,int n){
    for(int i=n-1;i>=index;i--){
        a[i+1]=a[i];
        a[index]=key;
        
        }
        
        
    }


void deletion(int a[],int index,int n){
    for(int i=index;i<=n-1;i++){
        a[i]=a[i+1];
    }
}

int search(int a[],int key,int n){
    for(int i=0;i<n;i++){
        if(a[i]==key){
            printf(" kkey found at index %d",i);
            return 0;
        }
        
    }
    printf("key not found\n");
}

void traverse(int a[],int n){
    for(int i=0;i<n;i++){
        printf("%d\n",a[i]);
    }
}

void update(int a[],int index,int key,int n){
    a[index]=key;
}

int main()
{
   int a[100],key,index,n,i,choice;
   printf(" enter the size of array\n");
   scanf("%d",&n);
   printf(" enter the elements\n");
   for(i=0;i<n;i++){
       scanf("%d",&a[i]);
   }
  while(1){
      
   printf(" ENTER YOUR CHOICE:\n 1.INSERTION\n2.DELETION\n3.SEARCHING\n4.TRAVERSAL\n5.UPDATE\n6.EXIT");
   scanf("%d",&choice);
   
       switch(choice){
           
           case 1:
           printf("enter the key and index where it should be inserted\n");
           scanf("%d%d",&index,&key);
           insert(a,n,index,key);
           break;
           
           case 2: 
           printf("enter the index where it should be performed\n");
           scanf("%d",&index);
           deletion(a,n,index);
           break;
           
           case 3:
           printf("enter the key needs  to search\n");
           scanf("%d",&key);
           break;
           
           case 4: 
           traverse(a,n);
           break;
           
           case 5:
           printf(" enter the key and index\n");
           scanf("%d%d",&index,&key);
           break;
           
           case 6:
           exit(1);
           break;
           default:
           printf("Invalid choice\n");
           
       }
   }

    return 0;
}

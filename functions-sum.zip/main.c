/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void sum( int,int,int,int,int);

void sum( inta,intb,intc,intd,inte){
    int a,b,c,d,e,sum,avg;
    printf(" enter the numbers\n");
    scanf(" %d%d%d%d%d",&a,&b,&c,&d,&e);
    sum=a+b+c+d+e;
    printf(" sum is %d\n",sum);
    avg=sum/5;
    printf("avg is %d",avg);
}
void main(){
    int m,n,p,q,r;
    sum(m,n,p,q,r);
}
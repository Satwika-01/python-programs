'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def swap(listt):
    length = len(listt)
    temp=listt[0]
    listt[0]=listt[length-1]
    listt[length-1]=temp
    for i in listt:
        print(i)
        
    
listt = ["ab","cd","ef","gh","ij"]
swap(listt)
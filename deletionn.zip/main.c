/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void deletion(int a[],int key,int n ){
    int ind;
    ind= search(a,key,n);
    for(int i=ind;i<n;i++)
    a[i]=a[i+1];
    for(int i=0;i<n-1;i++)
    printf("%d ",a[i]);
}
int search(int a[],int key,int n){
    for(int i=0;i<n;i++)
    if(a[i]==key)
    {return i;
    return 0;
    }
    
    
   printf("element not found\n");
    return -1;
}
int main()
{
    int a[10],i,n,index,key;
    printf("enter thr size of array\n");
    scanf("%d",&n);
    printf("enter the elements\n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    printf("enter the  key\n");
    scanf("%d",&key);
    deletion(a,key,n);

    return 0;
}

'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
dic ={}
array = [1,2,2,4,1,5,5,2]
n=len(array)
for i in range(n):
    if array[i] not in dic:
        dic[array[i]]=1 
    else:
        dic[array[i]]+=1 
for key,value in dic.items():
    print(key,value)
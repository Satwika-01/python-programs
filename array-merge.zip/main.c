/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[10],b[10],m,n,i,j,temp;
  printf(" enter thr number of elements\n");
  scanf("%d",&m);
  printf(" enter the elements\n");
  for(i=0;i<m;i++){
      scanf("%d",&a[i]);
  }
   printf(" enter thr number of elements\n");
  scanf("%d",&n);
  printf(" enter the elements\n");
  for(i=0;i<n;i++){
      scanf("%d",&b[i]);
  }
  for(i=0;i<m;i++){
      for(j=i+1;j<m;j++){
          if(a[i]>a[j]){
              temp=a[i];
              a[i]=a[j];
              a[j]=temp;
          }
      }
  }
  
  for(i=0;i<n;i++){
      for(j=i+1;j<n;j++){
          if(b[i]>b[j]){
              temp=b[i];
              b[i]=b[j];
              b[j]=temp;
          }
      }
  }
  
  printf(" merged array is\n");
  for(i=m,j=0;j<n;i++,j++){
      a[i]=b[j];
  }
  for(i=0;i<m+n;i++){
      for(j=i+1;j<m+n;j++){
          
          if( a[i]>a[j]){
              temp=a[i];
              a[i]=a[j];
              a[j]=temp;
          }
      }
      
     
  }
      for(i=0;i<m+n;i++){
          printf("%d ",a[i]);
      }
  
      

       
   
    return 0;
}

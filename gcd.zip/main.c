/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int gcd(int a,int b){
    if(a==0)
    return b;
    else if(b==0)
    return a;
    else if (a<b)
    return gcd(a,b%a);
    else
    return gcd(a%b,b);
    
}

int main()
{
   int a,b;
   printf("enter the numbers\n");
   scanf("%d%d",&a,&b);
  
  printf("%d",gcd(a,b)); 
   

    return 0;
}

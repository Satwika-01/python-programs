#d=  {
 #('A','B'):'Alpha',('1','2'):'Num'
#    }
    
d1={
    'India':'Delhi'
}
print(d1.get('India'))
print("\n")
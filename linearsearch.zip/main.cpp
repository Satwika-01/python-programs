/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void linear_search(int arr[],int n,int ele){
    
    for(int i=0;i<n;i++){
        if(arr[i]==ele){
            cout<<"Element "<<arr[i]<<"is found at position "<<i+1;
            return;
        }
    }
    cout<<"Element not found\n";
}

int main()
{
   int arr[10],ele,i,n;
   cout<<"enter the size\n";
   cin>>n;
   cout<<"enter the elements\n";
   for(i=0;i<n;i++){
       cin>>arr[i];
   }
   cout<<"enter the element\n";
   cin>>ele;
   linear_search(arr,n,ele);

    return 0;
}
l1=[1,2,3,4,5]
l2=[2,5,6,7,8]
for i in l1:
    if i in l2:
        print(i)
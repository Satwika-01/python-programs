/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void insertion(int arr[],int n){
    int i,j,key;
    for(i=1;i<n;i++){
        j=i-1;
        key=arr[i];
        while(j>=0 and arr[j]>key){
            
                arr[j+1]=arr[j];
                j--;
            
            
            
        }
        arr[j+1]=key;
    }
    cout<<"Sorted array is\n";
    for(i=0;i<n;i++)
    cout<<arr[i]<<" ";
}

int main()
{
   int n,arr[100];
   cout<<"Enter the size\n";
   cin>>n;
   cout<<"Enter the numbers\n";
   for(int i=0;i<n;i++)
   cin>>arr[i];
   insertion(arr,n);

    return 0;
}
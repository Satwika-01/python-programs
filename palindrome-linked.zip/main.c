/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
int pop();
void push();
struct node{
    int data;
    struct node*next;
    struct node*top;
};

int main()
{
   int n;
   struct node*head=NULL;
   struct node*newnode;
   struct node*temp;
   top=NULL;
   printf("enter the size\n");
   scanf("%d",&n);
   while(n--){
       newnode=(struct node*)malloc(sizeof(struct node));
       newnode->next=NULL;
       printf("enter the data\n");
       scanf("%d",&newnode->data);
       if(head==NULL)
       head=newnode;
       
       else{
           temp=head;
           while(temp!=NULL){
               temp=temp->next;
           }
           temp->next=newnode;
       }
   }
   push(head);
   pop(head);

    return 0;
}
